# {{name}}

A hybrid Meteorite service with both inline Lua handlers and transportable Zig
handlers.

## Commands

```bash
moon sync
moon run dev
moon run build
moon run run
```
