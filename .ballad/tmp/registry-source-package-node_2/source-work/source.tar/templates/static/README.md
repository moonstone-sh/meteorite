# {{name}}

A static Meteorite service: Lua declares the graph at build time, but request
handling is pure Zig and `moon run build` emits a server without the Lua runtime.

## Commands

```bash
moon sync
moon run generate-graph
moon run build
moon run run
```
