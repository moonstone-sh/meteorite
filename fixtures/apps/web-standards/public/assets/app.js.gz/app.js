console.log("meteorite standards");
